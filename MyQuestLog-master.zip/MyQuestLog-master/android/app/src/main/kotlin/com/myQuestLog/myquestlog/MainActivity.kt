package com.myQuestLog.myquestlog

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
