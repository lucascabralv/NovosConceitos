## 1.0.1
- fix: getInitialAppLink returning null 

## 1.0.0
- core: Initial release

## 0.2.0-dev
- Just don't use it!

## 0.1.0-dev
- Just don't use it!
