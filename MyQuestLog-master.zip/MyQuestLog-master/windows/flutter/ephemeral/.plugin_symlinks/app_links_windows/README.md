# app_links Windows

Windows implementation for app_links package.

See [README.md](https://github.com/llfbandit/app_links/blob/master/app_links/README.md)
